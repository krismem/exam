//
//  ViewController.swift
//  MyRestClient
//
//  Created by E. Menjivar on 08/07/2017.
//  Copyright © 2017 Berufs. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    let textCellIndicator = "CountryCell"

    @IBOutlet weak var countryTableView: UITableView!
    
    
    
    //Declaring my variables
    var fetchedCountry = [Country]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        countryTableView.dataSource = self
        
        ParseData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var prefersStatusBarHidden: Bool{
        return true
    }
    
    //-START
    //data table methods starts here
   
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int{
        return fetchedCountry.count
    }
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
    
        let cell = countryTableView.dequeueReusableCell(withIdentifier:
        textCellIndicator)
        
        cell?.textLabel?.text = fetchedCountry[indexPath.row].country
        cell?.detailTextLabel?.text = fetchedCountry[indexPath.row].capital
        
        return cell!
}
    //-END
    //Data Table
    
    
    func ParseData(){
        
        fetchedCountry = []
        
        
        //setting my url point
        let url = "https://restcountries.eu/rest/v1/all"
        
        //creating reques variable
        var request = URLRequest(url: URL(string: url)!)
        
        request.httpMethod = "GET"
        
        let configuration = URLSessionConfiguration.default
        
        
        //Build my default configuration
        let session = URLSession(configuration: configuration, delegate: nil, delegateQueue: OperationQueue.main)
        
        //getting my session data by a task method
        let task = session.dataTask(with: request)
        {
            (data, response, error) in
            
            if error != nil {
                print("error")
                
            }
            else
            {
                do
                    {
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves)
                        as! NSArray
                    
                        print(fetchedData)

                        //adding to country array
                        for eachFetchedCountry in fetchedData{
                            let eachCountry = eachFetchedCountry as! [String: Any]
                            
                            let country = eachCountry ["region"] as! String
                            let capital = eachCountry ["subregion"] as! String
                            
                            self.fetchedCountry.append(Country(country:country, capital:capital))
                        }
                
                        //printing object
                        print("-------")
                        print("------ getting data-------")
                        print("-------")
                
                        print (fetchedData)
                
                        print("-------")
                        print("------ Ending data -----")
                        print("-------")
                
                        self.countryTableView.reloadData()
                }
                catch
                {
                    print("Error 2")
                }
            }
        }
        task.resume()
    }
    
}

//Creation country class
class Country {
    var country : String
    var capital : String
    
    init (country : String, capital : String){
        self.country = country
        self.capital = capital
    }
}




